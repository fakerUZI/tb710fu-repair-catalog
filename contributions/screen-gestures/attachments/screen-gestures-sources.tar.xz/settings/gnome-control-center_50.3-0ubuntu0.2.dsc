-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: gnome-control-center
Binary: gnome-control-center, gnome-control-center-faces, gnome-control-center-dev, gnome-control-center-data
Architecture: any all
Version: 1:50.3-0ubuntu0.2
Maintainer: Ubuntu Developers <ubuntu-devel-discuss@lists.ubuntu.com>
Uploaders: Jeremy Bícha <jbicha@ubuntu.com>, Laurent Bigonville <bigon@debian.org>, Marco Trevisan (Treviño) <marco@ubuntu.com>
Standards-Version: 4.7.3
Vcs-Browser: https://salsa.debian.org/gnome-team/gnome-control-center/tree/ubuntu/resolute
Vcs-Git: https://salsa.debian.org/gnome-team/gnome-control-center.git -b ubuntu/resolute
Build-Depends: debhelper-compat (= 13), blueprint-compiler (>= 0.19.0), desktop-file-utils, dh-sequence-gnome (>= 0.22.2), gnome-settings-daemon-dev (>= 48~rc), gobject-introspection (>= 1.80), gsettings-desktop-schemas-dev (>= 50~alpha), gtk-doc-tools, libaccountsservice-dev (>= 23.11.69), libadwaita-1-dev (>= 1.8~alpha), libcolord-dev, libcolord-gtk4-dev (>= 0.1.24), libcups2-dev, libdrm-dev, libgcr-4-dev [linux-any], libgdk-pixbuf-2.0-dev, libglib2.0-dev (>= 2.76.6), libgnome-bg-4-dev, libgnome-bluetooth-ui-3.0-dev [linux-any], libgnome-desktop-4-dev, libgnutls28-dev, libgoa-1.0-dev (>= 3.51.0), libgoa-backend-1.0-dev (>= 3.51.0), libgsound-dev, libgtk-4-dev (>= 4.21), libgtop2-dev, libgudev-1.0-dev [linux-any], libhandy-1-dev (>= 1.2.0), libibus-1.0-dev, libinsights-dev (>= 0.8.1), libjson-glib-dev, libkrb5-dev, libmalcontent-0-dev (>= 0.14~alpha) [linux-any], libmm-glib-dev [linux-any], libnm-dev (>= 1.52.0) [linux-any], libnma-gtk4-dev (>= 1.10.2) [linux-any], libpolkit-gobject-1-dev, libpulse-dev, libpwquality-dev, libsecret-1-dev, libsmbclient-dev, libsoup-3.0-dev, libudisks2-dev, libupower-glib-dev (>= 1.90.6), libwacom-dev [linux-any], libwhoopsie-preferences-dev, libxml2-dev, libxml2-utils, locales, meson (>= 0.60.0), pkexec, python3-dbusmock <!nocheck>, shared-mime-info, tecla (>= 47), tzdata <!nocheck>
Package-List:
 gnome-control-center deb gnome optional arch=any
 gnome-control-center-data deb gnome optional arch=all
 gnome-control-center-dev deb devel optional arch=all
 gnome-control-center-faces deb gnome optional arch=all
Checksums-Sha1:
 29fdcab1f94ea8abed6d34b780937a019b76c486 7106028 gnome-control-center_50.3.orig.tar.xz
 8ada1b54544b171b3932ac08830bb086334a9612 115480 gnome-control-center_50.3-0ubuntu0.2.debian.tar.xz
Checksums-Sha256:
 06eebb0fd3056c4d8d78bbd3754c96108f381d70b760da423c5024946944287c 7106028 gnome-control-center_50.3.orig.tar.xz
 1a3f03ee31cad2a2652727919ce50ef41a3a71278ae565051444e765ea38150b 115480 gnome-control-center_50.3-0ubuntu0.2.debian.tar.xz
Files:
 0b7cad81105fde1027d0bd64cd9fb00a 7106028 gnome-control-center_50.3.orig.tar.xz
 dd65015805935065387fa24aeb93849d 115480 gnome-control-center_50.3-0ubuntu0.2.debian.tar.xz
Debian-Vcs-Browser: https://salsa.debian.org/gnome-team/gnome-control-center
Debian-Vcs-Git: https://salsa.debian.org/gnome-team/gnome-control-center.git
Original-Maintainer: Debian GNOME Maintainers <pkg-gnome-maintainers@lists.alioth.debian.org>

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEQ7A+KDJsVM+i7GajQPZQZq18FtsFAmp+YRAACgkQQPZQZq18
FttipRAAirgU/zqX4Oo9aDncv8rS9As9By46SBx8hyJ3xldrwkDUhxp9aLTD72By
faNabTe3MrfqQ0OV6jIRpkXSZOVcIJziip+gkYMWZCfdMrOIUGLaE7ls0RNPYvc1
wlMbtj8zwvA+rKjPHLp1QMcnvPbMkBhXKmXUUvepBKyuG0eMzo/5hbzr0K4+Il7F
Lt/rVSKclnUEDcSNpWz66IFXarxck0VWQgw/EOKc7l+GZYw+BpXBDFbcVlbY58QV
qaqwk71fRyq6lnde0OVeNywzq5T6RvL8GzQT/gHTW64Sa+jSKCmt++Ip1LSLX2Gx
NztBtMNefzQzo74Mi7BlLOZsyIYhU2rjTV9JBAniRJOWH+6rbF/ixlSSvqTvsGWp
hnK0XYDNj7D4mEwZyRFc64vBCPtogOlCi4jx+8v4AZF5ieBOtWaL3lzQBD07FxZ0
5oPFqDyfKxEK2HVytq3oRglMRgOnfjlY+4xjSUG9d/zHncukkpwMXe86PR2DGosy
qUe6Icg247Al3GfNFGiNgJCpMYxbUpiTbpYSJs2ttUKQWOOgDKyrjCEP5YsMxq2a
aSchCWOAQxG1Sjbg8qSz5z0afTyFj2XBnhvW3B+PiOn6xisJWLspik/2Foi9J8E0
fLH/B4QWcLucWfw9QSkcnrWgfWK6QIGnJegYbEBRy0st4HLFfB4=
=+ucH
-----END PGP SIGNATURE-----
