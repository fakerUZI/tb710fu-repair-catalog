// SPDX-License-Identifier: GPL-2.0-only
/*
 * Novatek NT36532 WQHD Dual-DSI Panel Driver
 *
 * Based on panel-novatek-nt36532e.c architecture,
 * integrating values from panel-nt36532-wqhd-dual-dsi-dsc.c
 */

#include <linux/backlight.h>
#include <linux/delay.h>
#include <linux/gpio/consumer.h>
#include <linux/module.h>
#include <linux/of.h>
#include <linux/of_graph.h>
#include <linux/regulator/consumer.h>
#include <linux/suspend.h>
#include <drm/drm_of.h>
#include <video/mipi_display.h>

#include <drm/display/drm_dsc.h>
#include <drm/display/drm_dsc_helper.h>
#include <drm/drm_connector.h>
#include <drm/drm_crtc.h>
#include <drm/drm_mipi_dsi.h>
#include <drm/drm_modes.h>
#include <drm/drm_panel.h>

#define DSI_NUM_MIN 1

/* Offline candidate: the established 120-Hz path remains the default.
 * 144 Hz must be enabled explicitly for a supervised, reversible trial. */
static bool experimental_144hz = true;
static bool prefer_144hz_trial = true;
/* Disabled unless explicitly selected for a reversible experiment. */
static bool experimental_low_refresh;
static bool prefer_60hz_trial;
module_param(prefer_60hz_trial, bool, 0444);
module_param(experimental_low_refresh, bool, 0444);
module_param(prefer_144hz_trial, bool, 0444);
module_param(experimental_144hz, bool, 0444);
MODULE_PARM_DESC(experimental_144hz,
	"Expose unvalidated 144 Hz mode in addition to default 120 Hz");

#define TB710FU_HTOTAL (3200 + 276 + 16 + 32)
#define TB710FU_VTOTAL (2000 + 26 + 2 + 232)
#define TB710FU_CLOCK_KHZ(hz) (TB710FU_HTOTAL * TB710FU_VTOTAL * (hz) / 1000)

struct panel_info {
	struct drm_panel panel;
	struct drm_connector *connector;
	struct mipi_dsi_device *dsi[2];
	struct panel_desc *desc;
	enum drm_panel_orientation orientation;
	unsigned int active_refresh_hz;

	struct gpio_desc *reset_gpio;
	bool supplies_on;
	bool dt2w_enabled;
	bool suspending;
	struct notifier_block pm_notifier;
	/* vddio, vci, vdd, avdd, avee — 社区参考的 bias 是单路 aw37504，
	 * 本树主线 aw37503 拆成 VPOS/avdd 与 VNEG/avee 两路，故多一路 */
	struct regulator_bulk_data supplies[5];
};

struct panel_desc {
	unsigned int width_mm;
	unsigned int height_mm;

	unsigned int bpc;
	unsigned int lanes;
	unsigned long mode_flags;
	enum mipi_dsi_pixel_format format;

	const struct drm_display_mode *modes;
	unsigned int num_modes;
	const struct mipi_dsi_device_info dsi_info;
	int (*init_sequence)(struct panel_info *pinfo);

	bool is_dual_dsi;

	struct drm_dsc_config dsc;
};

static inline struct panel_info *to_panel_info(struct drm_panel *panel)
{
	return container_of(panel, struct panel_info, panel);
}

/* Called by prepare after the atomic state swap, before shared rails/reset
 * are changed. Refuse arbitrary modelines rather than send mismatched panel
 * commands. The default-disabled candidate preserves the original path. */
static int nt36532_select_refresh(struct panel_info *pinfo)
{
	const struct drm_display_mode *mode;
	struct drm_connector_state *state;
	int refresh;

	pinfo->active_refresh_hz = 120;
	if (!experimental_144hz && !experimental_low_refresh)
		return 0;
	if (!pinfo->connector || !pinfo->connector->state)
		return -EINVAL;
	state = pinfo->connector->state;
	if (!state->crtc || !state->crtc->state)
		return -EINVAL;
	mode = &state->crtc->state->adjusted_mode;
	refresh = drm_mode_vrefresh(mode);
	if (mode->hdisplay != 3200 || mode->vdisplay != 2000 ||
	    mode->hsync_start != 3476 || mode->hsync_end != 3492 ||
	    mode->htotal != TB710FU_HTOTAL ||
	    mode->flags || mode->vscan > 1)
		return -EINVAL;
	if ((refresh == 120 || (experimental_144hz && refresh == 144)) &&
	    mode->vsync_start == 2026 && mode->vsync_end == 2028 &&
	    mode->vtotal == TB710FU_VTOTAL &&
	    abs(mode->clock - TB710FU_CLOCK_KHZ(refresh)) <= 1) {
		/* Existing verified modes. */
	} else if (experimental_low_refresh && refresh == 60 &&
	    mode->clock == TB710FU_CLOCK_KHZ(120) &&
	    mode->vtotal == 4520 &&
	    mode->vsync_start == mode->vtotal - 234 &&
	    mode->vsync_end == mode->vtotal - 232) {
		/* Extend VFP, retaining the existing 120-Hz link clock. */
	} else {
		return -EINVAL;
	}
	pinfo->active_refresh_hz = refresh;
	return 0;
}

static int nt36532_wqhd_init_sequence(struct panel_info *pinfo)
{
	struct mipi_dsi_multi_context dsi_ctx = { .dsi = pinfo->dsi[0] };
	struct drm_dsc_picture_parameter_set pps;

	/* Commands sent only to dsi0 here. qcom,sync-dual-dsi in dsi nodes will send them to both dsi ports */
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xff, 0x2a);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xfb, 0x01);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xbc, 0x66, 0x06);
	
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xff, 0xf0);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xfb, 0x01);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xfa, 0x05);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x76, 0x16);
	
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xff, 0x27);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xfb, 0x01);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xd0, 0x13);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xd1, 0x54);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xd2, 0x38);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xde, 0x40);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xdf, 0x02);
	
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xff, 0x23);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xfb, 0x01);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x00, 0x80);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x05, 0x24);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x07, 0x00);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x08, 0x01);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x09, 0xc2);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x10, 0x00);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x11, 0x03);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x12, 0xeb);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x15, 0x15);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x16, 0x13);
	
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x30, 0xff);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x31, 0xff);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x32, 0xff);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x33, 0xfc);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x34, 0xf9);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x35, 0xf5);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x36, 0xf2);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x37, 0xf0);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x38, 0xed);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x39, 0xeb);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x3a, 0xe8);
	
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x3b, 0xe5);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x3d, 0xe3);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x3f, 0xe0);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x40, 0xde);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x41, 0xdb);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x58, 0xff);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x59, 0xff);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x5a, 0xfa);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x5b, 0xf7);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x5c, 0xf2);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x5d, 0xeb);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x5e, 0xe3);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x5f, 0xd9);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x60, 0xd1);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x61, 0xcc);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x62, 0xc7);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x63, 0xbf);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x64, 0xba);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x65, 0xb5);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x66, 0xb0);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x67, 0xab);
	
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x19, 0x00);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x1a, 0x02);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x1b, 0x04);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x1c, 0x08);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x1d, 0x0e);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x1e, 0x14);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x1f, 0x18);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x20, 0x1e);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x21, 0x22);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x22, 0x26);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x23, 0x2a);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x24, 0x30);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x25, 0x34);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x26, 0x38);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x27, 0x3c);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x28, 0x3f);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x29, 0x10);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x2b, 0x28);
	
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xff, 0x25);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xfb, 0x01);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xc0, 0x0c);
	
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xff, 0x24);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xfb, 0x01);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x98, 0x80);
	
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xff, 0x10);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xfb, 0x01);
	// Enable pwm
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x51, 0x0f, 0xff);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x53, 0x24);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x55, 0x01);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x3b, 0x03, 0xea, 0x1a, 0x04, 0x04, 0x00);
	
	/* DSC Enable */
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x90, 0x03);
	/* mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x91,
				     0xab, 0xa8, 0x00, 0x14, 0xd2, 0x00, 0x00,
				     0x00, 0x02, 0x2b, 0x00, 0x0b, 0x05, 0x7a,
				     0x03, 0x68);
	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x92, 0x10, 0xe0); */

	drm_dsc_pps_payload_pack(&pps, &pinfo->desc->dsc);
	mipi_dsi_picture_parameter_set_multi(&dsi_ctx, &pps);

	mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0x9d, 0x01);
	/* Exact current Android vendor commands, page 0x10 unlocked above.
	 * The 144-Hz DSI/PHY timing still needs a supervised hardware trial. */
	if (pinfo->active_refresh_hz == 144) {
		mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xb2, 0x80);
		mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xb3, 0x00);
	} else {
		/* Factory 60 and 120 Hz share this command. */
		mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xb2, 0x91);
		mipi_dsi_dcs_write_seq_multi(&dsi_ctx, 0xb3, 0x40);
	}
	
	/* Start Display */
	mipi_dsi_dcs_exit_sleep_mode_multi(&dsi_ctx);
	mipi_dsi_msleep(&dsi_ctx, 120);

	mipi_dsi_dcs_set_display_on_multi(&dsi_ctx);
	mipi_dsi_msleep(&dsi_ctx, 20);

	return dsi_ctx.accum_err;
}

static const struct drm_display_mode nt36532_wqhd_modes[] = {
	{
		/* 120Hz */
		.clock = (3200 + 276 + 16 + 32) * (2000 + 26 + 2 + 232) * 120 / 1000,
		.hdisplay = 3200,
		.hsync_start = 3200 + 276,
		.hsync_end = 3200 + 276 + 16,
		.htotal = 3200 + 276 + 16 + 32,
		.vdisplay = 2000,
		.vsync_start = 2000 + 26,
		.vsync_end = 2000 + 26 + 2,
		.vtotal = 2000 + 26 + 2 + 232,
	},
	{
		.clock = TB710FU_CLOCK_KHZ(144),
		.hdisplay = 3200,
		.hsync_start = 3200 + 276,
		.hsync_end = 3200 + 276 + 16,
		.htotal = TB710FU_HTOTAL,
		.vdisplay = 2000,
		.vsync_start = 2000 + 26,
		.vsync_end = 2000 + 26 + 2,
		.vtotal = TB710FU_VTOTAL,
	},
	{
		/* 60 Hz: same pixel clock, doubled vertical total. */
		.clock = TB710FU_CLOCK_KHZ(120),
		.hdisplay = 3200, .hsync_start = 3476, .hsync_end = 3492,
		.htotal = TB710FU_HTOTAL, .vdisplay = 2000,
		.vsync_start = 4286, .vsync_end = 4288, .vtotal = 4520,
	},
};

static struct panel_desc nt36532_wqhd_desc = {
	.modes = nt36532_wqhd_modes,
	.num_modes = ARRAY_SIZE(nt36532_wqhd_modes),
	.dsi_info = {
		.type = "NT63532-lenovo",
		.channel = 0,
		.node = NULL,
	},
	.width_mm = 185,
	.height_mm = 150,
	.bpc = 8,
	.lanes = 4,
	.format = MIPI_DSI_FMT_RGB888,
	.mode_flags = MIPI_DSI_MODE_VIDEO | MIPI_DSI_CLOCK_NON_CONTINUOUS |
		      MIPI_DSI_MODE_LPM,
	.init_sequence = nt36532_wqhd_init_sequence,
	.is_dual_dsi = true,
	.dsc = {
		.dsc_version_major = 0x1,
		.dsc_version_minor = 0x1,
		.slice_height = 20,
		.slice_width = 800,
		.slice_count = 2,
		.bits_per_component = 8,
		.bits_per_pixel = 8 << 4,
		.block_pred_enable = true,
	},
};

static void nt36532_reset(struct panel_info *pinfo)
{
	gpiod_set_value_cansleep(pinfo->reset_gpio, 1);
	usleep_range(10000, 11000);
	gpiod_set_value_cansleep(pinfo->reset_gpio, 0);
	usleep_range(10000, 11000);
	gpiod_set_value_cansleep(pinfo->reset_gpio, 1);
	usleep_range(10000, 11000);
	gpiod_set_value_cansleep(pinfo->reset_gpio, 0);
	usleep_range(10000, 11000);
}

static int nt36532_power_off(struct panel_info *pinfo)
{
	int ret;

	if (!pinfo->supplies_on)
		return 0;
	gpiod_set_value_cansleep(pinfo->reset_gpio, 1);
	ret = regulator_bulk_disable(ARRAY_SIZE(pinfo->supplies), pinfo->supplies);
	if (!ret)
		pinfo->supplies_on = false;
	return ret;
}

static void nt36532_power_cleanup(void *data)
{
	nt36532_power_off(data);
}

static const struct drm_panel_funcs nt36532_panel_funcs;
bool tb710fu_panel_dt2w_enabled(struct drm_panel *panel);
bool tb710fu_touch_dt2w_armed(struct drm_panel *panel, bool disarm);

bool tb710fu_panel_dt2w_enabled(struct drm_panel *panel)
{
	struct panel_info *pinfo;

	if (panel->funcs != &nt36532_panel_funcs)
		return false;
	pinfo = to_panel_info(panel);
	return pinfo->dt2w_enabled && !pinfo->suspending;
}
EXPORT_SYMBOL_GPL(tb710fu_panel_dt2w_enabled);

static bool nt36532_touch_armed(struct panel_info *pinfo, bool disarm)
{
	typeof(&tb710fu_touch_dt2w_armed) touch_armed;
	bool armed;

	touch_armed = symbol_get(tb710fu_touch_dt2w_armed);
	if (!touch_armed)
		return false;
	armed = touch_armed(&pinfo->panel, disarm);
	symbol_put(tb710fu_touch_dt2w_armed);
	return armed;
}

/* The caller holds follower_lock, also used by DRM for prepare/unprepare. */
static int nt36532_drop_gesture_power(struct panel_info *pinfo)
{
	if (pinfo->panel.prepared)
		return 0;
	nt36532_touch_armed(pinfo, true);
	return nt36532_power_off(pinfo);
}

static ssize_t dt2w_enabled_show(struct device *dev,
				struct device_attribute *attr, char *buf)
{
	struct panel_info *pinfo = dev_get_drvdata(dev);

	return sysfs_emit(buf, "%u\n", READ_ONCE(pinfo->dt2w_enabled));
}

static ssize_t dt2w_enabled_store(struct device *dev, struct device_attribute *attr,
				 const char *buf, size_t count)
{
	struct panel_info *pinfo = dev_get_drvdata(dev);
	bool enabled;
	int ret;

	ret = kstrtobool(buf, &enabled);
	if (ret)
		return ret;

	mutex_lock(&pinfo->panel.follower_lock);
	ret = enabled ? 0 : nt36532_drop_gesture_power(pinfo);
	if (!ret)
		WRITE_ONCE(pinfo->dt2w_enabled, enabled);
	mutex_unlock(&pinfo->panel.follower_lock);
	return ret ? ret : count;
}
static DEVICE_ATTR_RW(dt2w_enabled);

static struct attribute *nt36532_gesture_attrs[] = {
	&dev_attr_dt2w_enabled.attr,
	NULL,
};
static const struct attribute_group nt36532_gesture_group = {
	.attrs = nt36532_gesture_attrs,
};

static int nt36532_system_pm(struct notifier_block *nb, unsigned long action,
			     void *unused)
{
	struct panel_info *pinfo = container_of(nb, struct panel_info, pm_notifier);
	int ret = 0;

	mutex_lock(&pinfo->panel.follower_lock);
	switch (action) {
	case PM_SUSPEND_PREPARE:
	case PM_HIBERNATION_PREPARE:
	case PM_RESTORE_PREPARE:
		pinfo->suspending = true;
		ret = nt36532_drop_gesture_power(pinfo);
		if (ret)
			pinfo->suspending = false;
		break;
	case PM_POST_SUSPEND:
	case PM_POST_HIBERNATION:
	case PM_POST_RESTORE:
		pinfo->suspending = false;
		break;
	}
	mutex_unlock(&pinfo->panel.follower_lock);
	return notifier_from_errno(ret);
}

static void nt36532_pm_cleanup(void *data)
{
	struct panel_info *pinfo = data;

	unregister_pm_notifier(&pinfo->pm_notifier);
}

static int nt36532_prepare(struct drm_panel *panel)
{
	struct panel_info *pinfo = to_panel_info(panel);
	int ret;

	ret = nt36532_select_refresh(pinfo);
	if (ret)
		return dev_err_probe(panel->dev, ret, "unsupported panel mode\n");
	dev_info(panel->dev, "prepare %u Hz\n", pinfo->active_refresh_hz);

	if (!pinfo->supplies_on) {
		ret = regulator_bulk_enable(ARRAY_SIZE(pinfo->supplies), pinfo->supplies);
		if (ret < 0) {
			dev_err(panel->dev, "failed to enable regulators: %d\n", ret);
			return ret;
		}
		pinfo->supplies_on = true;
	}

	nt36532_reset(pinfo);

	ret = pinfo->desc->init_sequence(pinfo);
	if (ret < 0) {
		nt36532_power_off(pinfo);
		dev_err(panel->dev, "failed to initialize panel: %d\n", ret);
		return ret;
	}

	return 0;
}

static int nt36532_disable(struct drm_panel *panel)
{
	struct panel_info *pinfo = to_panel_info(panel);
	struct mipi_dsi_multi_context dsi_ctx = { .dsi = pinfo->dsi[0] };

	dev_info(panel->dev, "disable\n");

	mipi_dsi_dcs_set_display_off_multi(&dsi_ctx);
	msleep(50);

	mipi_dsi_dcs_enter_sleep_mode_multi(&dsi_ctx);
	msleep(120);
	
	return dsi_ctx.accum_err;
}

static int nt36532_unprepare(struct drm_panel *panel)
{
	struct panel_info *pinfo = to_panel_info(panel);

	dev_info(panel->dev, "unprepare\n");

	if (tb710fu_panel_dt2w_enabled(panel) && nt36532_touch_armed(pinfo, false))
		return 0;
	nt36532_touch_armed(pinfo, true);
	return nt36532_power_off(pinfo);
}

static void nt36532_remove(struct mipi_dsi_device *dsi)
{
	/* devm_drm_panel_alloc 托管生命周期，无需 drm_panel_remove */
}

static int nt36532_get_modes(struct drm_panel *panel,
			       struct drm_connector *connector)
{
	struct panel_info *pinfo = to_panel_info(panel);
	int i, count = 0;

	for (i = 0; i < pinfo->desc->num_modes; i++) {
		const struct drm_display_mode *m = &pinfo->desc->modes[i];
		struct drm_display_mode *mode;

		if ((i == 1 && !experimental_144hz) ||
		    (i >= 2 && !experimental_low_refresh))
			continue;
		mode = drm_mode_duplicate(connector->dev, m);
		if (!mode) {
			dev_err(panel->dev, "failed to add mode %ux%u@%u\n",
				m->hdisplay, m->vdisplay, drm_mode_vrefresh(m));
			return -ENOMEM;
		}

		mode->type = DRM_MODE_TYPE_DRIVER;
		if (i == ((experimental_low_refresh && prefer_60hz_trial) ? 2 :
			  ((experimental_144hz && prefer_144hz_trial) ? 1 : 0)))
			mode->type |= DRM_MODE_TYPE_PREFERRED;

		drm_mode_set_name(mode);
		drm_mode_probed_add(connector, mode);
		count++;
	}

	connector->display_info.width_mm = pinfo->desc->width_mm;
	connector->display_info.height_mm = pinfo->desc->height_mm;
	connector->display_info.bpc = pinfo->desc->bpc;
	pinfo->connector = connector;

	return count;
}

static enum drm_panel_orientation nt36532_get_orientation(struct drm_panel *panel)
{
	struct panel_info *pinfo = to_panel_info(panel);

	return pinfo->orientation;
}

static const struct drm_panel_funcs nt36532_panel_funcs = {
	.disable = nt36532_disable,
	.prepare = nt36532_prepare,
	.unprepare = nt36532_unprepare,
	.get_modes = nt36532_get_modes,
	.get_orientation = nt36532_get_orientation,
};

static int nt36532_probe(struct mipi_dsi_device *dsi)
{
	struct device *dev = &dsi->dev;
	struct device_node *dsi1;
	struct mipi_dsi_host *dsi1_host;
	struct panel_info *pinfo;
	const struct mipi_dsi_device_info *info;
	int i, ret;

	/* 7.2 起用 devm_drm_panel_alloc 取代 drm_panel_init+drm_panel_add */
	pinfo = devm_drm_panel_alloc(dev, struct panel_info, panel,
				     &nt36532_panel_funcs,
				     DRM_MODE_CONNECTOR_DSI);
	if (IS_ERR(pinfo))
		return PTR_ERR(pinfo);

	pinfo->supplies[0].supply = "vddio";
	pinfo->supplies[1].supply = "vci";
	pinfo->supplies[2].supply = "vdd";
	pinfo->supplies[3].supply = "avdd";
	pinfo->supplies[4].supply = "avee";
	ret = devm_regulator_bulk_get(dev, ARRAY_SIZE(pinfo->supplies), pinfo->supplies);
	if (ret < 0)
		return dev_err_probe(dev, ret, "failed to get regulators\n");

	pinfo->reset_gpio = devm_gpiod_get(dev, "reset", GPIOD_OUT_HIGH);
	if (IS_ERR(pinfo->reset_gpio))
		return dev_err_probe(dev, PTR_ERR(pinfo->reset_gpio), "failed to get reset gpio\n");

	ret = devm_add_action_or_reset(dev, nt36532_power_cleanup, pinfo);
	if (ret)
		return ret;

	pinfo->desc = (struct panel_desc *)of_device_get_match_data(dev);
	if (!pinfo->desc)
		return -ENODEV;

	/* If the panel is dual dsi, register DSI1 */
	if (pinfo->desc->is_dual_dsi) {
		info = &pinfo->desc->dsi_info;

		dsi1 = of_graph_get_remote_node(dsi->dev.of_node, 1, -1);
		if (!dsi1) {
			dev_err(dev, "cannot get secondary DSI node.\n");
			return -ENODEV;
		}

		dsi1_host = of_find_mipi_dsi_host_by_node(dsi1);
		of_node_put(dsi1);
		if (!dsi1_host)
			return dev_err_probe(dev, -EPROBE_DEFER, "cannot get secondary DSI host\n");

		pinfo->dsi[1] = devm_mipi_dsi_device_register_full(dev, dsi1_host, info);
		if (IS_ERR(pinfo->dsi[1])) {
			dev_err(dev, "cannot get secondary DSI device\n");
			return PTR_ERR(pinfo->dsi[1]);
		}
	}

	pinfo->dsi[0] = dsi;
	mipi_dsi_set_drvdata(dsi, pinfo);

        ret = of_drm_get_panel_orientation(dev->of_node, &pinfo->orientation);
	if (ret < 0) {
		dev_err(dev, "%pOF: failed to get orientation %d\n", dev->of_node, ret);
		return ret;
	}

	pinfo->panel.prepare_prev_first = true;

	ret = drm_panel_of_backlight(&pinfo->panel);
        if (ret)
                return dev_err_probe(dev, ret, "Failed to get backlight\n");

	/*
	 * devm_drm_panel_alloc() 只做 kzalloc + drm_panel_init，不注册；
	 * 必须显式 add。缺少它时 of_drm_find_panel() 找不到面板，
	 * dsi_bind() 的 devm_drm_of_get_bridge() 拿不到 next_bridge，
	 * msm 组件聚合失败 → 没有 card0。这就是之前"面板 probe 成功但无
	 * card0"的根因。
	 */
	ret = devm_drm_panel_add(dev, &pinfo->panel);
	if (ret)
		return dev_err_probe(dev, ret, "failed to add panel\n");

        for (i = 0; i < DSI_NUM_MIN + pinfo->desc->is_dual_dsi; i++) {
		pinfo->dsi[i]->lanes = pinfo->desc->lanes;
		pinfo->dsi[i]->format = pinfo->desc->format;
		pinfo->dsi[i]->mode_flags = pinfo->desc->mode_flags;
		pinfo->dsi[i]->dsc = &pinfo->desc->dsc;
		/* 7.2 无 dsc_slice_per_pkt 字段，用 mode flag 表达每包全 slice */
		pinfo->dsi[i]->mode_flags |= MIPI_DSI_MODE_DSC_ALL_SLICES_IN_PKT;

		ret = mipi_dsi_attach(pinfo->dsi[i]);
		if (ret < 0)
			return dev_err_probe(dev, ret, "cannot attach to DSI%d host.\n", i);
	}

	mipi_dsi_set_drvdata(dsi, pinfo);
	pinfo->pm_notifier.notifier_call = nt36532_system_pm;
	ret = register_pm_notifier(&pinfo->pm_notifier);
	if (ret)
		return dev_err_probe(dev, ret, "cannot register gesture PM notifier\n");
	ret = devm_add_action_or_reset(dev, nt36532_pm_cleanup, pinfo);
	if (ret)
		return ret;

	return devm_device_add_group(dev, &nt36532_gesture_group);
}

static const struct of_device_id nt36532_of_match[] = {
	{
		.compatible = "lenovo,nt36532-wqhd",
		.data = &nt36532_wqhd_desc,
	},
	{},
};
MODULE_DEVICE_TABLE(of, nt36532_of_match);

static struct mipi_dsi_driver nt36532_driver = {
	.probe = nt36532_probe,
	.remove = nt36532_remove,
	.driver = {
		.name = "panel-novatek-nt36532-wqhd",
		.of_match_table = nt36532_of_match,
	},
};
module_mipi_dsi_driver(nt36532_driver);

MODULE_AUTHOR("Driver Author");
MODULE_DESCRIPTION("DRM driver for Novatek NT36532 WQHD based MIPI DSI panels");
MODULE_LICENSE("GPL");

MODULE_VERSION("tb710fu-screen-gestures-panel-20261122.1");
