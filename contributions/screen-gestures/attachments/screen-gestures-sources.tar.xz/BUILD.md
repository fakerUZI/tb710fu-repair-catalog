# Source for the TB710FU screen gesture build

The binaries distributed here are ARM64. The panel and touch directories are the corresponding replacement module source, including the already verified Display Off / Sleep In sequence. To rebuild them, prepare the exact Linux 7.2.6 TB710FU dated 20261118 configuration and Module.symvers following the [dated kernel source build](https://github.com/fakerUZI/tb710fu-repair-catalog/tree/main/contributions/kernel-offline-upgrade/attachments). The expected uncompressed kernel configuration SHA-256 is listed in the repair's spec.json. On Linux ARM64, with the matching toolchain, run in that prepared kernel tree:

```sh
make LOCALVERSION= CONFIG_TOUCHSCREEN_NT36XXX_SPI=m M=/absolute/source/touch modules
make LOCALVERSION= M=/absolute/source/panel modules
aarch64-linux-gnu-strip --strip-debug /absolute/source/touch/nvt_36xxx.ko
aarch64-linux-gnu-strip --strip-debug /absolute/source/panel/panel-nt36532-wqhd-dual-dsi-dsc.ko
```

The Ubuntu GNOME Settings source is the unmodified Ubuntu 26.04 package 1:50.3-0ubuntu0.2. Extract it with `dpkg-source -x gnome-control-center_50.3-0ubuntu0.2.dsc` and install the package's declared build dependencies. In the extracted directory apply `screen-lock.patch`, `automatic-brightness.patch`, and `screen-gestures.patch` in that order with `patch --fuzz=0 -p1`. Run:

```sh
dh_auto_configure -- -Dlocation-services=enabled -Dprivileged_group=sudo -Dwhoopsie=true \
  -Dinsights=true -Ddocumentation=true -Dmalcontent=true \
  -Ddistributor_logo=/usr/share/pixmaps/ubuntu-logo-text.svg \
  -Ddark_mode_distributor_logo=/usr/share/pixmaps/ubuntu-logo-text-dark.svg
ninja -C obj-aarch64-linux-gnu shell/gnome-control-center
strip --strip-unneeded obj-aarch64-linux-gnu/shell/gnome-control-center
```

The patched DING file is distributed in source form. The Ubuntu source package and in-file notices contain upstream copyright and license information.
